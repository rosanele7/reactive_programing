/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mx.rx.example.observers;

import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

/**
 *
 * @author RosarioElena
 */
public class RxObservableImpl {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Observable<String> news = Observable.create(emitter -> {
            try {
                emitter.onNext("New 1");
                emitter.onNext("New 2");
                emitter.onNext("New 3");
                emitter.onComplete();
            } catch (Exception e) {
                emitter.onError(e);
            }
        });
        
        Observable<String> news2 = Observable.just("New 1A", "New 2A", "New 3A");
        
        Observer<String> reader1 = new Observer<String>() {
            @Override
            public void onSubscribe(Disposable dspsbl) {
            }

            @Override
            public void onNext(String news) {
                System.out.println("Reader 1 got the news: " + news);
            }

            @Override
            public void onError(Throwable e) {
                e.printStackTrace();
            }

            @Override
            public void onComplete() {
                System.out.println("There are no more news to read");
            }
        };
        
        news.subscribe(reader1);
        
        news2.subscribe(System.out::println, 
                Throwable::printStackTrace, 
                ()->System.out.println("operation complete"));
        news2.subscribe(e->System.out.println("Reader 1 " + e));
    }
    
}
