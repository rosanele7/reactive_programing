/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mx.rx.example.publisher;

import io.reactivex.Flowable;

/**
 *
 * @author RosarioElena
 */
public class RandomNumberGenerator {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Flowable.range(1, 4).
                map(i -> Math.random()).
                subscribe(number -> System.out.println("Got random number " + number));
    }
    
}
