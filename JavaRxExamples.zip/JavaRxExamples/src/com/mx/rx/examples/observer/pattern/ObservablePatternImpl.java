/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mx.rx.examples.observer.pattern;

/**
 *
 * @author RosarioElena
 */
public class ObservablePatternImpl {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        News observedNews = new News();
        
        FirstNewsReader reader1 = new FirstNewsReader();
        SecondNewsReader reader2 = new SecondNewsReader();
        
        observedNews.addObserver(reader1);
        observedNews.addObserver(reader2);
        observedNews.news();
        
    }
    
}
