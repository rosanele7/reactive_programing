/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mx.rx.examples.observer.pattern;

import java.util.Observable;

/**
 *
 * @author RosarioElena
 */
public class News extends Observable {
    
    public void news() {
        String[] news = {"New 1", "New 2", "New 3"};
        for (String s : news) {
            //set change
            setChanged();
            
            //notify observer for change
            notifyObservers(s);
            try {
                Thread.sleep(1000);
            } catch (InterruptedException ex) {
                System.out.println("Error Ocurred");
            }
        }
    }
}
