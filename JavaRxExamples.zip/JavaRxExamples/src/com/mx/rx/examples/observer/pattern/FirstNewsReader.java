/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mx.rx.examples.observer.pattern;

import java.util.Observable;
import java.util.Observer;

/**
 *
 * @author RosarioElena
 */
public class FirstNewsReader implements Observer {

    @Override
    public void update(Observable obs, Object obj) {
        System.out.println("FirstNewsReader got The news: " + (String)obj 
                + " thread name " + Thread.currentThread().getName());
    }
    
}
